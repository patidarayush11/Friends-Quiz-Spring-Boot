package com.bffquest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BffQuestApplication {

	public static void main(String[] args) {
		SpringApplication.run(BffQuestApplication.class, args);
	}

}
